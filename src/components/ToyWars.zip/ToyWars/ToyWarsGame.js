import React, { useState, useEffect } from "react";
import Navigation from "./Navigation";
import Marketplace from "./Marketplace";
import Inventory from "./Inventory";
// Import subcomponents here

const ToyWarsGame = () => {
  const baseToyPrices = {
    "Yo-Yo": 5,
    "Rubik's Cube": 10,
    "Cabbage Patch Kids": 20,
    Tamagotchi: 30,
    "Nintendo Game Boy": 50,
    iPad: 200,
  };

  const [gameState, setGameState] = useState({
    cash: 1000,
    inventory: [],
    currentCity: "New York",
    vehicleCapacity: 50,
    toys: Object.keys(baseToyPrices).map((name) => ({
      name,
      price: baseToyPrices[name],
    })),
    // Other game state variables
  });

  const rerollToyPrices = () => {
    setGameState((prevState) => ({
      ...prevState,
      toys: prevState.toys.map((toy) => ({
        ...toy,
        price: calculateNewPrice(baseToyPrices[toy.name]),
      })),
    }));
  };

  const calculateNewPrice = (basePrice) => {
    const variance = Math.random() * 0.5 - 0.25; // Random number between -0.25 and +0.25
    return Math.round(basePrice * (1 + variance));
  };

  const setCurrentCity = (city) => {
    setGameState((prevState) => ({
      ...prevState,
      currentCity: city,
    }));
  };

  // Load game state from localStorage when the component mounts
  useEffect(() => {
    const savedGameState = localStorage.getItem("toyWarsGameState");
    if (savedGameState) {
      setGameState(JSON.parse(savedGameState));
    }
  }, []);

  // Save game state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("toyWarsGameState", JSON.stringify(gameState));
  }, [gameState]);

  // Game logic functions go here
  // E.g., functions to handle buying, selling, changing cities, etc.

  return (
    <div>
      <h1>Toy Wars Game</h1>
      <Navigation
        currentCity={gameState.currentCity}
        setCurrentCity={setCurrentCity}
        gameState={gameState}
        setGameState={setGameState}
        rerollToyPrices={rerollToyPrices}
      />

      <Marketplace gameState={gameState} setGameState={setGameState} />
      <Inventory gameState={gameState} />
    </div>
  );
};

export default ToyWarsGame;
